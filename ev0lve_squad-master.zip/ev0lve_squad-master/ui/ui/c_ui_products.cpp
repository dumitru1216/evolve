//
// Created by ruppet on 2/5/2020.
//

#include <d3dx9.h>
#include "c_ui.h"
#include "c_ui_products.h"

void c_ui_products::draw(c_ui_window *wnd) {

}

void c_ui_products::setup(std::string n) {

}