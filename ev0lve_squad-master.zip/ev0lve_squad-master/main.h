//
// Created by ruppet on 3/1/2020.
//

#ifndef EV0LVE_APEX_CM_MAIN_H
#define EV0LVE_APEX_CM_MAIN_H

#include <Windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <Shlobj.h>
#include <WinInet.h>
#include <optional>

#include "ui/imgui.h"
#include "ui/imgui_internal.h"
#include "ui/imgui_impl_win32.h"
#include "ui/imgui_impl_dx9.h"
#include "ui/ui/c_ui.h"

extern bool g_is_initialized;
extern c_ui* g_ui;
extern IDirect3DDevice9Ex* g_device;

#pragma comment(lib, "WinInet.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "wbemuuid.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

#endif //EV0LVE_APEX_CM_MAIN_H
