# ev0lve_squad
Squad cheese config
