#include "main.h"

bool g_is_initialized = false;
c_ui* g_ui = nullptr;
IDirect3DDevice9Ex* g_device = nullptr;

auto g_accent = new float[4] {
    0.f,
    120.f / 255.f,
    1.f,
    1.f
};

void setup_window();

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

LRESULT WINAPI WndProc(HWND hwnd, UINT msg, WPARAM w, LPARAM l) {
    if (!g_is_initialized)
        return DefWindowProcA(hwnd, msg, w, l);

    static auto can_drag = [hwnd]() -> bool {
        RECT rect;
        if (!GetWindowRect(hwnd, &rect))
            return false;

        POINT cur;
        GetCursorPos(&cur);

        auto y = cur.y - rect.top;
        auto x = cur.x - rect.left;
        return y <= 40 && x <= (rect.right - rect.left) - 30;
    };

    ImGui_ImplWin32_WndProcHandler(hwnd, msg, w, l);

    if (msg == WM_CLOSE || msg == WM_DESTROY)
        exit(0);
    if (msg == WM_NCHITTEST && can_drag())
        return HTCAPTION;

    return DefWindowProcA(hwnd, msg, w, l);
}

std::string do_get_request(std::string url) {
    std::string request_data = "";

    auto hIntSession = InternetOpenA("", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hIntSession)
        return request_data;
    auto hHttpSession = InternetConnectA(hIntSession, "raw.githubusercontent.com", 80, 0, 0, INTERNET_SERVICE_HTTP, 0, NULL);
    if ( !hHttpSession )
        return request_data;

    auto hHttpRequest = HttpOpenRequestA( hHttpSession , "GET" , url.c_str(), 0 , 0 , 0 , INTERNET_FLAG_RELOAD , 0 );

    auto szHeaders =  "Content-Type: text/html";
    char szRequest[1024] = { 0 };

    if ( !HttpSendRequestA( hHttpRequest , szHeaders , strlen( szHeaders ) , szRequest , strlen( szRequest ) ) )
        return request_data;

    CHAR szBuffer[1024] = { 0 };
    DWORD dwRead = 0;

    while ( InternetReadFile( hHttpRequest , szBuffer , sizeof( szBuffer ) - 1 , &dwRead ) && dwRead )
        request_data.append( szBuffer , dwRead );

    InternetCloseHandle( hHttpRequest );
    InternetCloseHandle( hHttpSession );
    InternetCloseHandle( hIntSession );

    return request_data;
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
    LoadLibraryA("wininet.dll");
    LoadLibraryA("ole32.dll");
    LoadLibraryA("ws2_32.dll");
    LoadLibraryA("d3d9.dll");
    LoadLibraryA("oleaut32.dll");

    auto ver = do_get_request("/1337Ruppet/ev0lve_squad/master/version.txt");
    if (ver != "apple\n") {
        MessageBoxA(0, "A new version of configurator has been released. Please refer to GitHub repository to download new build!",
                "New version", MB_OK | MB_ICONINFORMATION);
        return 0;
    }

    MessageBoxA(0, "The configurator automatically rewrites your config when any value is being changed. Please, keep that in mind!", "WARNING", MB_OK | MB_ICONWARNING);

    WNDCLASSEX wc{};
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = 0;
    wc.hCursor = LoadCursorA(0, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)5;
    wc.lpszClassName = "Chrome_WidgetWin_69";

    if (!RegisterClassExA(&wc)) {
        MessageBoxA(0, "Failed to register window class", "Startup failed", MB_OK | MB_ICONERROR);
        return false;
    }

    RECT screen_size;
    GetWindowRect(GetDesktopWindow(), &screen_size);

    auto x = screen_size.right / 2 - 350 / 2, y = screen_size.bottom / 2 - 250 / 2;

    auto hwnd = CreateWindowExA(WS_EX_LAYERED, "Chrome_WidgetWin_69",
                                     "ev0lve Squad", WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, x, y,
                                     715, 480, 0, 0, 0, 0);
    if (!hwnd) {
        MessageBoxA(0, "Failed to create window", "Startup failed", MB_OK | MB_ICONERROR);
        return false;
    }

    IDirect3D9Ex* directx = nullptr;

    Direct3DCreate9Ex(D3D_SDK_VERSION, &directx);
    if (!directx) {
        MessageBoxA(0, "Failed to create D3D9", "Startup failed", MB_OK | MB_ICONERROR);
        return false;
    }

    D3DPRESENT_PARAMETERS pp{};
    pp.Windowed = true;
    pp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    pp.hDeviceWindow = hwnd;

    directx->CreateDeviceEx(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hwnd, D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                            &pp, 0, &g_device);

    if (!g_device) {
        MessageBoxA(0, "Failed to create device", "Startup failed", MB_OK | MB_ICONERROR);
        return false;
    }

    ImGui::CreateContext();
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX9_Init(g_device);

    g_ui = new c_ui;
    g_ui->setup();

    setup_window();

    SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA);
    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);

    SetFocus(hwnd);
    SetForegroundWindow(hwnd);

    g_is_initialized = true;

    while (true) {
        MSG msg;
        if (PeekMessageA(&msg, 0, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageA(&msg);
        }

        if (!g_device || !directx) break;

        g_device->Clear(0, 0, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 0), 1.f, 0);
        g_device->BeginScene();

        ImGui_ImplWin32_NewFrame();
        ImGui_ImplDX9_NewFrame();
        ImGui::NewFrame();

        g_ui->style.e_accent = ImColor(g_accent[0], g_accent[1], g_accent[2], g_accent[3]);
        g_ui->draw();

        ImGui::EndFrame();
        ImGui::Render();
        ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());

        g_device->EndScene();
        g_device->Present(0, 0, 0, 0);
    }
}

void setup_window() {
    char cfg_path[MAX_PATH];

    static std::string path;
    if (SUCCEEDED(SHGetFolderPath(NULL, CSIDL_APPDATA, NULL, 0, cfg_path)))
    {
        path = cfg_path;
        path += "/_ev0lve/config_squad_alpha.ini";
    }

    static auto window = new c_ui_window;
    window->setup("ev0lve.xyz for Squad", g_device);
    window->set_pos(ImVec2(0, 0));
    window->set_size(ImVec2(715, 480));
    window->set_active(true);

    {
        static auto aim = new c_ui_tab;
        aim->setup("AIMBOT");
        aim->set_tab(0, 3);
        aim->set_icon(u8"\uE04F");
        aim->set_active(true);
        {
            static auto general = new c_ui_group;
            general->setup("Settings");
            general->set_pos(ImVec2(20.f, 10.f));
            general->set_size(ImVec2(295.f, 410.f));
            {
                static auto fov = new c_ui_slider_int;
                fov->setup("FOV", new int(0), 0, 50);
                fov->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Aimbot", "aimbot_fov", std::to_string(fov->get_value()).c_str(), path.c_str());
                });
                fov->set_value(GetPrivateProfileIntA("Aimbot", "aimbot_fov", 0, path.c_str()));

                static auto smooth = new c_ui_slider_int;
                smooth->setup("Smoothness", new int(0), 0, 50);
                smooth->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Aimbot", "aimbot_smooth", std::to_string(smooth->get_value()).c_str(), path.c_str());
                });
                smooth->set_value(GetPrivateProfileIntA("Aimbot", "aimbot_smooth", 0, path.c_str()));

                static auto bone = new c_ui_dropdown;
                bone->setup("Bone", new int(0));
                bone->add("Head");
                bone->add("Chest");
                bone->add("Body");
                bone->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Aimbot", "aimbot_bone", std::to_string(7 - bone->get_value()).c_str(), path.c_str());
                });
                bone->set_value(7 - GetPrivateProfileIntA("Aimbot", "aimbot_bone", 0, path.c_str()));

                static auto aimtime = new c_ui_slider_int;
                aimtime->setup("Aimtime", new int(0), 0, 1000, "%dms");
                aimtime->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Aimbot", "aimbot_aimtime", std::to_string(aimtime->get_value()).c_str(), path.c_str());
                });
                aimtime->set_value(GetPrivateProfileIntA("Aimbot", "aimbot_aimtime", 0, path.c_str()));

                static auto nonsticky = new c_ui_checkbox;
                nonsticky->setup("No stick", new bool(false));
                nonsticky->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Aimbot", "aimbot_nonsticky", std::to_string(nonsticky->get_value()).c_str(), path.c_str());
                });
                nonsticky->set_value(GetPrivateProfileIntA("Aimbot", "aimbot_nonsticky", 0, path.c_str()));

                static auto type = new c_ui_dropdown;
                type->setup("Mode", new int(0));
                type->add("Disabled");
                type->add("Default");
                type->add("None");
                type->add("Magic");
                type->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Aimbot", "aimbot_mode", std::to_string(type->get_value()).c_str(), path.c_str());
                });
                type->set_value(GetPrivateProfileIntA("Aimbot", "aimbot_mode", 0, path.c_str()));

                static auto ts = new c_ui_checkbox;
                ts->setup("Target selection", new bool(false));
                ts->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Aimbot", "aimbot_target_selection_enabled", std::to_string(ts->get_value()).c_str(), path.c_str());
                });
                ts->set_value(GetPrivateProfileIntA("Aimbot", "aimbot_target_selection_enabled", 0, path.c_str()));

                static auto df = new c_ui_checkbox;
                df->setup("Dynamic FOV", new bool(false));
                df->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Aimbot", "aimbot_dynamicfov_enabled", std::to_string(df->get_value()).c_str(), path.c_str());
                });
                df->set_value(GetPrivateProfileIntA("Aimbot", "aimbot_dynamicfov_enabled", 0, path.c_str()));

                static auto mbmd = new c_ui_slider_int;
                mbmd->setup("Maximal magic bullet distance", new int(0), 0, 50);
                mbmd->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Aimbot", "magic_bullet_max_distance", std::to_string(mbmd->get_value()).c_str(), path.c_str());
                });
                mbmd->set_value(GetPrivateProfileIntA("Aimbot", "magic_bullet_max_distance", 0, path.c_str()));

                static auto fm = new c_ui_slider_int;
                fm->setup("FOV modifier", new int(0), 0, 10);
                fm->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Aimbot", "fov_modifier_value", std::to_string(fm->get_value()).c_str(), path.c_str());
                });
                fm->set_value(GetPrivateProfileIntA("Aimbot", "fov_modifier_value", 0, path.c_str()));

                static auto sm = new c_ui_slider_int;
                sm->setup("Smoothness modifier", new int(0), 0, 10);
                sm->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Aimbot", "smooth_modifier_value", std::to_string(sm->get_value()).c_str(), path.c_str());
                });
                sm->set_value(GetPrivateProfileIntA("Aimbot", "smooth_modifier_value", 0, path.c_str()));

                general->add(fov);
                general->add(smooth);
                general->add(bone);
                general->add(aimtime);
                general->add(nonsticky);
                general->add(type);
                general->add(ts);
                general->add(df);
                general->add(mbmd);
                general->add(fm);
                general->add(sm);
            }

            static auto keys = new c_ui_group;
            keys->setup("Keybinds");
            keys->set_pos(ImVec2(325.f, 10.f));
            keys->set_size(ImVec2(295.f, 410.f));
            {
                static auto aimbot = new c_ui_hotkey;
                aimbot->setup("Aimbot", new int(114));
                aimbot->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Keybinds", "keybind_aimbot", std::to_string(aimbot->get_value()).c_str(), path.c_str());
                });
                aimbot->set_value(GetPrivateProfileIntA("Keybinds", "keybind_aimbot", 114, path.c_str()));

                static auto fovp = new c_ui_hotkey;
                fovp->setup("FOV +", new int(114));
                fovp->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Keybinds", "keybind_fov_add", std::to_string(fovp->get_value()).c_str(), path.c_str());
                });
                fovp->set_value(GetPrivateProfileIntA("Keybinds", "keybind_fov_add", 114, path.c_str()));

                static auto fovm = new c_ui_hotkey;
                fovm->setup("FOV -", new int(114));
                fovm->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Keybinds", "keybind_fov_substruct", std::to_string(fovm->get_value()).c_str(), path.c_str());
                });
                fovm->set_value(GetPrivateProfileIntA("Keybinds", "keybind_fov_substruct", 114, path.c_str()));

                static auto smoothp = new c_ui_hotkey;
                smoothp->setup("Smoothness +", new int(114));
                smoothp->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Keybinds", "keybind_smooth_add", std::to_string(smoothp->get_value()).c_str(), path.c_str());
                });
                smoothp->set_value(GetPrivateProfileIntA("Keybinds", "keybind_smooth_add", 114, path.c_str()));

                static auto smoothm = new c_ui_hotkey;
                smoothm->setup("Smoothness -", new int(114));
                smoothm->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Keybinds", "keybind_smooth_substruct", std::to_string(smoothm->get_value()).c_str(), path.c_str());
                });
                smoothm->set_value(GetPrivateProfileIntA("Keybinds", "keybind_smooth_substruct", 114, path.c_str()));

                keys->add(aimbot);
                keys->add(fovp);
                keys->add(fovm);
                keys->add(smoothp);
                keys->add(smoothm);
            }

            aim->add(general);
            aim->add(keys);
        }

        static auto visuals = new c_ui_tab;
        visuals->setup("VISUALS");
        visuals->set_tab(1, 3);
        visuals->set_icon(u8"\uE051");
        {
            static auto players = new c_ui_group;
            players->setup("Players");
            players->set_pos(ImVec2(20.f, 10.f));
            players->set_size(ImVec2(295.f, 410.f));
            {
                static auto dist = new c_ui_slider_int;
                dist->setup("Maximal distance", new int(0), 0, 5000);
                dist->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Esp", "esp_player_max_render_distance", std::to_string(dist->get_value()).c_str(), path.c_str());
                });
                dist->set_value(GetPrivateProfileIntA("Esp", "esp_player_max_render_distance", 0, path.c_str()));

                static auto onlyenemy = new c_ui_checkbox;
                onlyenemy->setup("Enemies only", new bool(false));
                onlyenemy->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Esp", "esp_bEnemyOnly", std::to_string(onlyenemy->get_value()).c_str(), path.c_str());
                });
                onlyenemy->set_value(GetPrivateProfileIntA("Esp", "esp_bEnemyOnly", 0, path.c_str()));

                players->add(dist);
                players->add(onlyenemy);

                {
                    static auto cb = new c_ui_checkbox;
                    cb->setup("Skeleton", new bool(false));
                    cb->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_bSkeleton_enable", std::to_string(cb->get_value()).c_str(), path.c_str());
                    });
                    cb->set_value(GetPrivateProfileIntA("Esp", "esp_bSkeleton_enable", 0, path.c_str()));

                    static auto col = new c_ui_colorpicker;
                    col->setup("Skeleton", new float[4]{0, 0, 0, 1});
                    col->set_draw_name(false);
                    col->set_alphabar(false);
                    col->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_skeleton_color_r", std::to_string(col->get_value(0) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_skeleton_color_g", std::to_string(col->get_value(1) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_skeleton_color_b", std::to_string(col->get_value(2) * 255.f).c_str(), path.c_str());
                    });
                    col->set_value(0, GetPrivateProfileIntA("Esp", "esp_skeleton_color_r", 255, path.c_str()) / 255.f);
                    col->set_value(1, GetPrivateProfileIntA("Esp", "esp_skeleton_color_g", 255, path.c_str()) / 255.f);
                    col->set_value(2, GetPrivateProfileIntA("Esp", "esp_skeleton_color_b", 255, path.c_str()) / 255.f);

                    static auto dd = new c_ui_slider_int;
                    dd->setup("Draw distance", new int(0), 0, 5000);
                    dd->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_skeleton_render_distance", std::to_string(dd->get_value()).c_str(), path.c_str());
                    });
                    dd->set_value(GetPrivateProfileIntA("Esp", "esp_skeleton_render_distance", 0, path.c_str()));

                    players->add(cb);
                    players->add(col);
                    players->add(dd);
                }

                {
                    static auto cb = new c_ui_checkbox;
                    cb->setup("Head dot", new bool(false));
                    cb->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_bHeaddot_enable", std::to_string(cb->get_value()).c_str(), path.c_str());
                    });
                    cb->set_value(GetPrivateProfileIntA("Esp", "esp_bHeaddot_enable", 0, path.c_str()));

                    static auto col = new c_ui_colorpicker;
                    col->setup("Head dot", new float[4]{0, 0, 0, 1});
                    col->set_draw_name(false);
                    col->set_alphabar(false);
                    col->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_headdot_color_r", std::to_string(col->get_value(0) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_headdot_color_g", std::to_string(col->get_value(1) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_headdot_color_b", std::to_string(col->get_value(2) * 255.f).c_str(), path.c_str());
                    });
                    col->set_value(0, GetPrivateProfileIntA("Esp", "esp_headdot_color_r", 255, path.c_str()) / 255.f);
                    col->set_value(1, GetPrivateProfileIntA("Esp", "esp_headdot_color_g", 255, path.c_str()) / 255.f);
                    col->set_value(2, GetPrivateProfileIntA("Esp", "esp_headdot_color_b", 255, path.c_str()) / 255.f);

                    static auto dd = new c_ui_slider_int;
                    dd->setup("Draw distance", new int(0), 0, 5000);
                    dd->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_headdot_render_distance", std::to_string(dd->get_value()).c_str(), path.c_str());
                    });
                    dd->set_value(GetPrivateProfileIntA("Esp", "esp_headdot_render_distance", 0, path.c_str()));

                    players->add(cb);
                    players->add(col);
                    players->add(dd);
                }

                {
                    static auto cb = new c_ui_checkbox;
                    cb->setup("Distance", new bool(false));
                    cb->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_bDistance_enable", std::to_string(cb->get_value()).c_str(), path.c_str());
                    });
                    cb->set_value(GetPrivateProfileIntA("Esp", "esp_bDistance_enable", 0, path.c_str()));

                    static auto col = new c_ui_colorpicker;
                    col->setup("Distance", new float[4]{0, 0, 0, 1});
                    col->set_draw_name(false);
                    col->set_alphabar(false);
                    col->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_distance_color_r", std::to_string(col->get_value(0) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_distance_color_g", std::to_string(col->get_value(1) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_distance_color_b", std::to_string(col->get_value(2) * 255.f).c_str(), path.c_str());
                    });
                    col->set_value(0, GetPrivateProfileIntA("Esp", "esp_distance_color_r", 255, path.c_str()) / 255.f);
                    col->set_value(1, GetPrivateProfileIntA("Esp", "esp_distance_color_g", 255, path.c_str()) / 255.f);
                    col->set_value(2, GetPrivateProfileIntA("Esp", "esp_distance_color_b", 255, path.c_str()) / 255.f);

                    players->add(cb);
                    players->add(col);
                }

                {
                    static auto cb = new c_ui_checkbox;
                    cb->setup("Name", new bool(false));
                    cb->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_bPlayername_enable", std::to_string(cb->get_value()).c_str(), path.c_str());
                    });
                    cb->set_value(GetPrivateProfileIntA("Esp", "esp_bPlayername_enable", 0, path.c_str()));

                    static auto col = new c_ui_colorpicker;
                    col->setup("Name", new float[4]{0, 0, 0, 1});
                    col->set_draw_name(false);
                    col->set_alphabar(false);
                    col->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_playername_color_r", std::to_string(col->get_value(0) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_playername_color_g", std::to_string(col->get_value(1) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_playername_color_b", std::to_string(col->get_value(2) * 255.f).c_str(), path.c_str());
                    });
                    col->set_value(0, GetPrivateProfileIntA("Esp", "esp_playername_color_r", 255, path.c_str()) / 255.f);
                    col->set_value(1, GetPrivateProfileIntA("Esp", "esp_playername_color_g", 255, path.c_str()) / 255.f);
                    col->set_value(2, GetPrivateProfileIntA("Esp", "esp_playername_color_b", 255, path.c_str()) / 255.f);

                    static auto dd = new c_ui_slider_int;
                    dd->setup("Draw distance", new int(0), 0, 5000);
                    dd->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_playername_render_distance", std::to_string(dd->get_value()).c_str(), path.c_str());
                    });
                    dd->set_value(GetPrivateProfileIntA("Esp", "esp_playername_render_distance", 0, path.c_str()));

                    players->add(cb);
                    players->add(col);
                    players->add(dd);
                }

                {
                    static auto cb = new c_ui_checkbox;
                    cb->setup("Weapons", new bool(false));
                    cb->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_bWeaponname_enable", std::to_string(cb->get_value()).c_str(), path.c_str());
                    });
                    cb->set_value(GetPrivateProfileIntA("Esp", "esp_bWeaponname_enable", 0, path.c_str()));

                    static auto col = new c_ui_colorpicker;
                    col->setup("Weapons", new float[4]{0, 0, 0, 1});
                    col->set_draw_name(false);
                    col->set_alphabar(false);
                    col->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_weaponname_color_r", std::to_string(col->get_value(0) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_weaponname_color_g", std::to_string(col->get_value(1) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_weaponname_color_b", std::to_string(col->get_value(2) * 255.f).c_str(), path.c_str());
                    });
                    col->set_value(0, GetPrivateProfileIntA("Esp", "esp_weaponname_color_r", 255, path.c_str()) / 255.f);
                    col->set_value(1, GetPrivateProfileIntA("Esp", "esp_weaponname_color_g", 255, path.c_str()) / 255.f);
                    col->set_value(2, GetPrivateProfileIntA("Esp", "esp_weaponname_color_b", 255, path.c_str()) / 255.f);

                    static auto dd = new c_ui_slider_int;
                    dd->setup("Draw distance", new int(0), 0, 5000);
                    dd->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_weaponname_render_distance", std::to_string(dd->get_value()).c_str(), path.c_str());
                    });
                    dd->set_value(GetPrivateProfileIntA("Esp", "esp_weaponname_render_distance", 0, path.c_str()));

                    players->add(cb);
                    players->add(col);
                    players->add(dd);
                }

                {
                    static auto cb = new c_ui_checkbox;
                    cb->setup("Health bar", new bool(false));
                    cb->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_bHealthbar_enable", std::to_string(cb->get_value()).c_str(), path.c_str());
                    });
                    cb->set_value(GetPrivateProfileIntA("Esp", "esp_bHealthbar_enable", 0, path.c_str()));

                    players->add(cb);
                }

                static auto box = new c_ui_checkbox;
                box->setup("Box", new bool(false));
                box->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Esp", "esp_bBox_enable", std::to_string(box->get_value()).c_str(), path.c_str());
                });
                box->set_value(GetPrivateProfileIntA("Esp", "esp_bBox_enable", 0, path.c_str()));

                static auto boxc = new c_ui_checkbox;
                boxc->setup("Box corner", new bool(false));
                boxc->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Esp", "esp_box_corner_enabled", std::to_string(boxc->get_value()).c_str(), path.c_str());
                });
                boxc->set_value(GetPrivateProfileIntA("Esp", "esp_box_corner_enabled", 0, path.c_str()));

                static auto boxcs = new c_ui_slider_int;
                boxcs->setup("Corner size", new int(0), 0, 200);
                boxcs->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Esp", "esp_box_corner_size", std::to_string(boxcs->get_value()).c_str(), path.c_str());
                });
                boxcs->set_value(GetPrivateProfileIntA("Esp", "esp_box_corner_size", 0, path.c_str()));

                static auto boxct = new c_ui_slider_int;
                boxct->setup("Corner thickness", new int(0), 0, 10);
                boxct->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Esp", "esp_box_corner_thickness", std::to_string(boxct->get_value()).c_str(), path.c_str());
                });
                boxct->set_value(GetPrivateProfileIntA("Esp", "esp_box_corner_thickness", 0, path.c_str()));

                static auto boxot = new c_ui_slider_int;
                boxot->setup("Outline thickness", new int(0), 0, 10);
                boxot->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Esp", "esp_box_outline_thickness", std::to_string(boxot->get_value()).c_str(), path.c_str());
                });
                boxot->set_value(GetPrivateProfileIntA("Esp", "esp_box_outline_thickness", 0, path.c_str()));

                players->add(box);
                players->add(boxc);
                players->add(boxcs);
                players->add(boxct);
                players->add(boxot);

                {
                    static auto col_label = new c_ui_label;
                    col_label->setup("Friendly");
                    col_label->set_text("Friendly");

                    static auto col = new c_ui_colorpicker;
                    col->setup("Friendly", new float[4]{0, 0, 0, 1});
                    col->set_draw_name(false);
                    col->set_alphabar(false);
                    col->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_box_friendly_color_r", std::to_string(col->get_value(0) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_box_friendly_color_g", std::to_string(col->get_value(1) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_box_friendly_color_b", std::to_string(col->get_value(2) * 255.f).c_str(), path.c_str());
                    });
                    col->set_value(0, GetPrivateProfileIntA("Esp", "esp_box_friendly_color_r", 0, path.c_str()) / 255.f);
                    col->set_value(1, GetPrivateProfileIntA("Esp", "esp_box_friendly_color_g", 160, path.c_str()) / 255.f);
                    col->set_value(2, GetPrivateProfileIntA("Esp", "esp_box_friendly_color_b", 255, path.c_str()) / 255.f);

                    players->add(col_label);
                    players->add(col);
                }

                {
                    static auto col_label = new c_ui_label;
                    col_label->setup("Enemy");
                    col_label->set_text("Enemy");

                    static auto col = new c_ui_colorpicker;
                    col->setup("Enemy", new float[4]{0, 0, 0, 1});
                    col->set_draw_name(false);
                    col->set_alphabar(false);
                    col->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_box_enemy_color_r", std::to_string(col->get_value(0) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_box_enemy_color_g", std::to_string(col->get_value(1) * 255.f).c_str(), path.c_str());
                        WritePrivateProfileStringA("Esp", "esp_box_enemy_color_b", std::to_string(col->get_value(2) * 255.f).c_str(), path.c_str());
                    });
                    col->set_value(0, GetPrivateProfileIntA("Esp", "esp_box_enemy_color_r", 234, path.c_str()) / 255.f);
                    col->set_value(1, GetPrivateProfileIntA("Esp", "esp_box_enemy_color_g", 7, path.c_str()) / 255.f);
                    col->set_value(2, GetPrivateProfileIntA("Esp", "esp_box_enemy_color_b", 151, path.c_str()) / 255.f);

                    players->add(col_label);
                    players->add(col);
                }
            }

            static auto other = new c_ui_group;
            other->setup("Other");
            other->set_pos(ImVec2(325.f, 10.f));
            other->set_size(ImVec2(295.f, 410.f));
            {
                {
                    static auto cb = new c_ui_checkbox;
                    cb->setup("Draw FOV", new bool(false));
                    cb->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_bDrawFov_enable", std::to_string(cb->get_value()).c_str(), path.c_str());
                    });
                    cb->set_value(GetPrivateProfileIntA("Esp", "esp_bDrawFov_enable", 0, path.c_str()));

                    other->add(cb);
                }

                {
                    static auto cb = new c_ui_checkbox;
                    cb->setup("Draw crosshair", new bool(false));
                    cb->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_bDrawCrosshair_enable", std::to_string(cb->get_value()).c_str(), path.c_str());
                    });
                    cb->set_value(GetPrivateProfileIntA("Esp", "esp_bDrawCrosshair_enable", 0, path.c_str()));

                    other->add(cb);
                }

                {
                    static auto cb = new c_ui_checkbox;
                    cb->setup("Font outline", new bool(false));
                    cb->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_bfont_outline_enable", std::to_string(cb->get_value()).c_str(), path.c_str());
                    });
                    cb->set_value(GetPrivateProfileIntA("Esp", "esp_bfont_outline_enable", 0, path.c_str()));

                    other->add(cb);
                }

                {
                    static auto cb = new c_ui_checkbox;
                    cb->setup("Local player healthbar", new bool(false));
                    cb->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_local_healthbar_enabled", std::to_string(cb->get_value()).c_str(), path.c_str());
                    });
                    cb->set_value(GetPrivateProfileIntA("Esp", "esp_local_healthbar_enabled", 0, path.c_str()));

                    other->add(cb);
                }

                {
                    static auto cb = new c_ui_checkbox;
                    cb->setup("Kill counter", new bool(false));
                    cb->set_callback([&](c_ui_element*) {
                        WritePrivateProfileStringA("Esp", "esp_kill_counter_enabled", std::to_string(cb->get_value()).c_str(), path.c_str());
                    });
                    cb->set_value(GetPrivateProfileIntA("Esp", "esp_kill_counter_enabled", 0, path.c_str()));

                    other->add(cb);
                }
            }

            visuals->add(players);
            visuals->add(other);
        }

        static auto misc = new c_ui_tab;
        misc->setup("MISC");
        misc->set_tab(2, 3);
        misc->set_icon(u8"\uE04C");
        {
            static auto miscellaneous = new c_ui_group;
            miscellaneous->setup("Miscellaneous");
            miscellaneous->set_pos(ImVec2(20.f, 10.f));
            miscellaneous->set_size(ImVec2(295.f, 410.f));
            {
                static auto speedhack = new c_ui_hotkey;
                speedhack->setup("Speedhack switch", new int(114));
                speedhack->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Keybinds", "keybind_switch_speedhack", std::to_string(speedhack->get_value()).c_str(), path.c_str());
                });
                speedhack->set_value(GetPrivateProfileIntA("Keybinds", "keybind_switch_speedhack", 114, path.c_str()));

                static auto speedhack_t = new c_ui_hotkey;
                speedhack_t->setup("Speedhack", new int(160));
                speedhack_t->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Keybinds", "keybind_speedhack", std::to_string(speedhack_t->get_value()).c_str(), path.c_str());
                });
                speedhack_t->set_value(GetPrivateProfileIntA("Keybinds", "keybind_speedhack", 160, path.c_str()));

                static auto sh_disabled = new c_ui_slider_float;
                sh_disabled->setup("Disabled value", new float(0), 0.f, 10.f);
                sh_disabled->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Misc", "misc_speedhack_value", std::to_string(sh_disabled->get_value()).c_str(), path.c_str());
                });

                char buf_0[64] = {0};
                GetPrivateProfileStringA("Misc", "misc_speedhack_value", "1.0", buf_0, 64, path.c_str());
                sh_disabled->set_value(atof(buf_0));

                static auto sh_enabled = new c_ui_slider_float;
                sh_enabled->setup("Enabled value", new float(0), 0.f, 10.f);
                sh_enabled->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Misc", "misc_speedhack_value2", std::to_string(sh_enabled->get_value()).c_str(), path.c_str());
                });

                char buf_1[64] = {0};
                GetPrivateProfileStringA("Misc", "misc_speedhack_value2", "1.2", buf_1, 64, path.c_str());
                sh_enabled->set_value(atof(buf_1));

                static auto rf = new c_ui_checkbox;
                rf->setup("Rapid fire", new bool(false));
                rf->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Misc", "misc_RapidFire_enabled", std::to_string(rf->get_value()).c_str(), path.c_str());
                });
                rf->set_value(GetPrivateProfileIntA("Misc", "misc_RapidFire_enabled", 0, path.c_str()));

                static auto ua = new c_ui_checkbox;
                ua->setup("Unlimited ammo", new bool(false));
                ua->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Misc", "misc_UnlimitedAmmo_enabled", std::to_string(ua->get_value()).c_str(), path.c_str());
                });
                ua->set_value(GetPrivateProfileIntA("Misc", "misc_UnlimitedAmmo_enabled", 0, path.c_str()));

                static auto firemode_c = new c_ui_checkbox;
                firemode_c->setup("Firemode changer", new bool(false));
                firemode_c->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Misc", "misc_Firemode_changer_enabled", std::to_string(firemode_c->get_value()).c_str(), path.c_str());
                });
                firemode_c->set_value(GetPrivateProfileIntA("Misc", "misc_Firemode_changer_enabled", 0, path.c_str()));

                static auto firemode_s = new c_ui_hotkey;
                firemode_s->setup("Switch firemode", new int(115));
                firemode_s->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Keybinds", "keybind_edit_firemode", std::to_string(firemode_s->get_value()).c_str(), path.c_str());
                });
                firemode_s->set_value(GetPrivateProfileIntA("Keybinds", "keybind_edit_firemode", 115, path.c_str()));

                static auto lrr = new c_ui_checkbox;
                lrr->setup("Long range resurrect", new bool(false));
                lrr->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Misc", "misc_lonrange_resurrect_enabled", std::to_string(lrr->get_value()).c_str(), path.c_str());
                });
                lrr->set_value(GetPrivateProfileIntA("Misc", "misc_lonrange_resurrect_enabled", 0, path.c_str()));

                static auto ufd = new c_ui_checkbox;
                ufd->setup("Unlimited field dressings", new bool(false));
                ufd->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Misc", "misc_UnlimitedFieldDressings_enabled", std::to_string(ufd->get_value()).c_str(), path.c_str());
                });
                ufd->set_value(GetPrivateProfileIntA("Misc", "misc_UnlimitedFieldDressings_enabled", 0, path.c_str()));

                static auto un = new c_ui_checkbox;
                un->setup("Unlimited grenades", new bool(false));
                un->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Misc", "misc_UnlimitedGrenades_enabled", std::to_string(un->get_value()).c_str(), path.c_str());
                });
                un->set_value(GetPrivateProfileIntA("Misc", "misc_UnlimitedGrenades_enabled", 0, path.c_str()));

                static auto sas = new c_ui_checkbox;
                sas->setup("Show all stats", new bool(false));
                sas->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Misc", "misc_bScoreBoardShowAllStats", std::to_string(sas->get_value()).c_str(), path.c_str());
                });
                sas->set_value(GetPrivateProfileIntA("Misc", "misc_bScoreBoardShowAllStats", 0, path.c_str()));

                static auto rr = new c_ui_checkbox;
                rr->setup("Recoil reducer", new bool(false));
                rr->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Misc", "misc_necoil_reducer", std::to_string(rr->get_value()).c_str(), path.c_str());
                });
                rr->set_value(GetPrivateProfileIntA("Misc", "misc_necoil_reducer", 0, path.c_str()));

                static auto hbm = new c_ui_checkbox;
                hbm->setup("Hitbox size modulation", new bool(false));
                hbm->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Misc", "misc_hitbox_mod_enable", std::to_string(hbm->get_value()).c_str(), path.c_str());
                });
                hbm->set_value(GetPrivateProfileIntA("Misc", "misc_hitbox_mod_enable", 0, path.c_str()));

                static auto hbsx = new c_ui_slider_float;
                hbsx->setup("X size", new float(0), 0.f, 10.f, "%.2f");
                hbsx->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Misc", "misc_hitbox_scale_x", std::to_string(hbsx->get_value()).c_str(), path.c_str());
                });

                char buf_2[64] = {0};
                GetPrivateProfileStringA("Misc", "misc_hitbox_scale_x", "1.00", buf_2, 64, path.c_str());
                hbsx->set_value(atof(buf_2));

                static auto hbsy = new c_ui_slider_float;
                hbsy->setup("Y size", new float(0), 0.f, 10.f, "%.2f");
                hbsy->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Misc", "misc_hitbox_scale_y", std::to_string(hbsy->get_value()).c_str(), path.c_str());
                });

                char buf_3[64] = {0};
                GetPrivateProfileStringA("Misc", "misc_hitbox_scale_y", "1.00", buf_3, 64, path.c_str());
                hbsy->set_value(atof(buf_3));

                static auto hbsz = new c_ui_slider_float;
                hbsz->setup("Z size", new float(0), 0.f, 10.f, "%.2f");
                hbsz->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Misc", "misc_hitbox_scale_z", std::to_string(hbsz->get_value()).c_str(), path.c_str());
                });

                char buf_4[64] = {0};
                GetPrivateProfileStringA("Misc", "misc_hitbox_scale_z", "1.00", buf_4, 64, path.c_str());
                hbsz->set_value(atof(buf_4));

                miscellaneous->add(speedhack_t);
                miscellaneous->add(speedhack);
                miscellaneous->add(sh_disabled);
                miscellaneous->add(sh_enabled);
                miscellaneous->add(rf);
                miscellaneous->add(ua);
                miscellaneous->add(firemode_c);
                miscellaneous->add(firemode_s);
                miscellaneous->add(lrr);
                miscellaneous->add(ufd);
                miscellaneous->add(un);
                miscellaneous->add(sas);
                miscellaneous->add(rr);
                miscellaneous->add(hbm);
                miscellaneous->add(hbsx);
                miscellaneous->add(hbsy);
                miscellaneous->add(hbsz);
            }

            static auto settings = new c_ui_group;
            settings->setup("Settings");
            settings->set_pos(ImVec2(325.f, 10.f));
            settings->set_size(ImVec2(295.f, 410.f));
            {
                static auto reload = new c_ui_hotkey;
                reload->setup("Reload config", new int(114));
                reload->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Keybinds", "keybind_reload_cfg", std::to_string(reload->get_value()).c_str(), path.c_str());
                });
                reload->set_value(GetPrivateProfileIntA("Keybinds", "keybind_reload_cfg", 122, path.c_str()));

                static auto save = new c_ui_hotkey;
                save->setup("Save config", new int(114));
                save->set_callback([&](c_ui_element*){
                    WritePrivateProfileStringA("Keybinds", "keybind_save_cfg", std::to_string(save->get_value()).c_str(), path.c_str());
                });
                save->set_value(GetPrivateProfileIntA("Keybinds", "keybind_save_cfg", 123, path.c_str()));

                static auto col_label = new c_ui_label;
                col_label->setup("Menu accent label");
                col_label->set_text("Menu accent");

                static auto col = new c_ui_colorpicker;
                col->setup("Menu accent", g_accent);
                col->set_draw_name(false);
                col->set_alphabar(false);
                col->set_callback([&](c_ui_element*) {
                    WritePrivateProfileStringA("Configurator", "accent_r", std::to_string(col->get_value(0) * 255.f).c_str(), path.c_str());
                    WritePrivateProfileStringA("Configurator", "accent_g", std::to_string(col->get_value(1) * 255.f).c_str(), path.c_str());
                    WritePrivateProfileStringA("Configurator", "accent_b", std::to_string(col->get_value(2) * 255.f).c_str(), path.c_str());
                });
                col->set_value(0, GetPrivateProfileIntA("Configurator", "accent_r", 0, path.c_str()) / 255.f);
                col->set_value(1, GetPrivateProfileIntA("Configurator", "accent_g", 120, path.c_str()) / 255.f);
                col->set_value(2, GetPrivateProfileIntA("Configurator", "accent_b", 255, path.c_str()) / 255.f);

                static auto about_1 = new c_ui_label;
                about_1->setup("About");
                about_1->set_text("// Made by panzerfaust");

                static auto about_2 = new c_ui_label;
                about_2->setup("About");
                about_2->set_text("// Special thanks to imi-tat0r");

                settings->add(reload);
                settings->add(save);
                settings->add(col_label);
                settings->add(col);
                settings->add(about_1);
                settings->add(about_2);
            }

            misc->add(miscellaneous);
            misc->add(settings);
        }

        window->add(aim);
        window->add(visuals);
        window->add(misc);
    }

    g_ui->add(window);
}